package com.herison.componente1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Componente1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
