package com.herison.componente1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Componente1Application {

	public static void main(String[] args) {
		SpringApplication.run(Componente1Application.class, args);
	}

}
